const conexion = require('../database/db');


exports.save = (req, res)=>{
    const nombre = req.body.nombre;
    const tipo = req.body.tipo;
    conexion.query('INSERT INTO paquetes SET ?',{nombre:nombre,tipo:tipo},(error, results)=>{
        if(error){
            console.log(error);
        }else{
            res.redirect('/');
        }
    })
};

exports.update = (req, res) =>{
    const id = req.body.id;
    const nombre = req.body.nombre;
    const tipo = req.body.tipo;
    conexion.query('UPDATE paquetes SET ? WHERE id = ?', [{nombre:nombre, tipo:tipo}, id], (error, results)=>{
        if(error){
            console.log(error);
        }else{
            res.redirect('/');
        }
    })
}